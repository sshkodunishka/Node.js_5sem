let http = require('http');
let url = require("url");

let factorial = (k) => { return (k === 0 ? 1 : factorial(k - 1) * k); }

http.createServer((request, response) => {
    if (request.url === '/') {
        response.writeHead(200, { 'Content-Type': 'text/html' });
        response.end(`<h1>Hello World!!!</h1>`)
    }
    if (request.url === '/fact') {
        if (url.parse(request.url).query === null) {
            // let k = 0;
            // response.writeHead(200, { 'Content-Type': 'text/html' });
            // response.end(JSON.stringify({ k: k, fact: factorial(k) }));
            response.writeHead(200, {'Content-Type': 'text/html'});
            response.end("Hello World");
        } else {
            let k = url.parse(request.url, true).query.k;
            response.writeHead(200, {'Content-Type': 'text/html'});
            response.end(JSON.stringify({k: k, fact: factorial(k)}));
        }
    }
}).listen(5000);

console.log('Server running...');